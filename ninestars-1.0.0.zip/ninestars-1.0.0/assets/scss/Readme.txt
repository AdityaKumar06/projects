The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/