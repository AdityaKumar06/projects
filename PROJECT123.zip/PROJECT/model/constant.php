<?php
if (!defined('HTTP_SERVER')) {
    define('HTTP_SERVER', 'http://localhost/PROJECT/');
}
