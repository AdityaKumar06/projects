<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>- DEMO</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>




   <!-- Services Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 service-item-top wow fadeInUp" data-wow-delay="0.1s">
                <div class="overflow-hidden">
                    <img class="img-fluid w-100 h-100" src="img/designeng-project.jpg" alt="Electronic Components">
                </div>
                <div class="d-flex align-items-center justify-content-between bg-light p-4">
                    <h5 class="text-truncate me-3 mb-0">Electronic Components</h5>
                    <a class="btn btn-square btn-outline-primary border-2 border-white flex-shrink-0" href="#"><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 service-item-top wow fadeInUp" data-wow-delay="0.3s">
                <div class="overflow-hidden">
                    <img class="img-fluid w-100 h-100" src="img/designeng-project.jpg" alt="Industrial Solutions">
                </div>
                <div class="d-flex align-items-center justify-content-between bg-light p-4">
                    <h5 class="text-truncate me-3 mb-0">Industrial Solutions</h5>
                    <a class="btn btn-square btn-outline-primary border-2 border-white flex-shrink-0" href="#"><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 service-item-top wow fadeInUp" data-wow-delay="0.5s">
                <div class="overflow-hidden">
                    <img class="img-fluid w-100 h-100" src="img/designeng-project.jpg" alt="Global Sourcing">
                </div>
                <div class="d-flex align-items-center justify-content-between bg-light p-4">
                    <h5 class="text-truncate me-3 mb-0">Global Sourcing</h5>
                    <a class="btn btn-square btn-outline-primary border-2 border-white flex-shrink-0" href="#"><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Services End -->


<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="text-secondary text-uppercase">About Us</h6>
                <h1 class="mb-4">We Are Encore Global – Your Trusted Industrial Partner Since 2022</h1>
                <p class="mb-4">
                    Encore Global Co., Limited, established in 2022 and headquartered in Hong Kong, is a dynamic and reliable provider of high-quality electronic components and industrial solutions. With global partnerships and deep industry expertise, we serve diverse sectors including electronics, automotive, manufacturing, and renewable energy.
                </p>
                <p class="fw-medium text-primary"><i class="fa fa-check text-success me-3"></i> Trusted sourcing partner across industries</p>
                <p class="fw-medium text-primary"><i class="fa fa-check text-success me-3"></i> Competitive pricing with quality assurance</p>
                <p class="fw-medium text-primary"><i class="fa fa-check text-success me-3"></i> Reliable 24/7 emergency support</p>
                <div class="bg-primary d-flex align-items-center p-4 mt-5">
                    <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-white" style="width: 60px; height: 60px;">
                        <i class="fa fa-phone-alt fa-2x text-primary"></i>
                    </div>
                    <div class="ms-3">
                        <p class="fs-5 fw-medium mb-2 text-white">Technical Support</p>
                        <h3 class="m-0 text-secondary">+012 345 6789</h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 pt-4" style="min-height: 500px;">
                <div class="position-relative h-100 wow fadeInUp" data-wow-delay="0.5s">
                    <img class="position-absolute img-fluid w-100 h-100" src="img/22.jpg" style="object-fit: cover; padding: 0 0 50px 100px;" alt="Encore Global Team">
                    <img class="position-absolute start-0 bottom-0 img-fluid bg-white pt-2 pe-2 w-50 h-50" src="img/22.jpg" style="object-fit: cover;" alt="Encore Global Solutions">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About End -->

    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>


  

</body>

</html>