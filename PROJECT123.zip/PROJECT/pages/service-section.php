<?php
include('../model/constant.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Our Services | Encore Global</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="Explore Encore Global's comprehensive services in electronic components and industrial solutions" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= HTTP_SERVER ?>lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?= HTTP_SERVER ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    
    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= HTTP_SERVER ?>css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= HTTP_SERVER ?>css/style.css" rel="stylesheet">
    
    <style>
        .service-card {
            transition: all 0.3s ease;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            height: 100%;
        }
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }
        .service-icon {
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #3a7bd5, #00d2ff);
            color: white;
            border-radius: 50%;
            font-size: 32px;
        }
        .service-bg {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('<?= HTTP_SERVER ?>img/service-bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            position: relative;
        }
        .feature-box {
            padding: 30px;
            border-radius: 10px;
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
        }
        .feature-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .feature-icon {
            color: #3a7bd5;
            font-size: 40px;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

<?php include '../include/layout/header.php' ?>

<?php include '../include/layout/navbar.php' ?>

<!-- Page Header Start -->
<div class="container-fluid page-header py-5 mb-5">
    <div class="container py-5">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Our Services</h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item text-white active" aria-current="page">Services</li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->

<!-- Service Overview Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
            <h6 class="text-primary text-uppercase">Our Solutions</h6>
            <h1 class="display-5 mb-4">Comprehensive Electronic Component Services</h1>
            <p class="mb-4">Encore Global delivers end-to-end solutions for your electronic component needs, from sourcing to supply chain management, backed by our global network and technical expertise.</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-microchip"></i>
                    </div>
                    <h4 class="mb-3">Component Sourcing</h4>
                    <p class="mb-4">Global procurement of high-quality electronic components with competitive pricing and reliable supply chains.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">Hard-to-find component solutions</li>
                        <li class="mb-2">Global supplier network</li>
                        <li class="mb-2">Quality assurance protocols</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-industry"></i>
                    </div>
                    <h4 class="mb-3">Industrial Solutions</h4>
                    <p class="mb-4">Comprehensive components and systems for industrial automation, control, and manufacturing applications.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">Automation components</li>
                        <li class="mb-2">Control systems</li>
                        <li class="mb-2">Manufacturing solutions</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-car-battery"></i>
                    </div>
                    <h4 class="mb-3">Automotive Electronics</h4>
                    <p class="mb-4">Specialized components for automotive applications including EV systems, sensors, and control modules.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">EV components</li>
                        <li class="mb-2">Vehicle sensors</li>
                        <li class="mb-2">Control modules</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-solar-panel"></i>
                    </div>
                    <h4 class="mb-3">Renewable Energy</h4>
                    <p class="mb-4">Components and systems for solar, wind, and other renewable energy applications.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">Solar power components</li>
                        <li class="mb-2">Energy storage</li>
                        <li class="mb-2">Power conversion</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <h4 class="mb-3">Supply Chain Management</h4>
                    <p class="mb-4">End-to-end supply chain solutions including logistics, inventory management, and just-in-time delivery.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">Global logistics</li>
                        <li class="mb-2">Inventory solutions</li>
                        <li class="mb-2">JIT delivery</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-card bg-white p-4 text-center">
                    <div class="service-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h4 class="mb-3">Technical Support</h4>
                    <p class="mb-4">Expert technical consultation and support for component selection, integration, and troubleshooting.</p>
                    <ul class="text-start ps-4 mb-4">
                        <li class="mb-2">Component selection</li>
                        <li class="mb-2">Integration support</li>
                        <li class="mb-2">Troubleshooting</li>
                    </ul>
                    <a href="" class="btn btn-primary py-2 px-4">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service Overview End -->

<!-- Industry Solutions Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
            <h6 class="text-primary text-uppercase">Industry Focus</h6>
            <h1 class="display-5 mb-4">Tailored Solutions for Your Industry</h1>
            <p class="mb-4">We understand that each industry has unique requirements. Our specialized solutions are designed to meet the specific challenges of your sector.</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="feature-box text-center p-4">
                    <div class="feature-icon mb-4">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <h5 class="mb-3">Consumer Electronics</h5>
                    <p class="mb-0">Components for smartphones, tablets, wearables, and home appliances.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="feature-box text-center p-4">
                    <div class="feature-icon mb-4">
                        <i class="fas fa-car-alt"></i>
                    </div>
                    <h5 class="mb-3">Automotive</h5>
                    <p class="mb-0">Reliable components for traditional and electric vehicles.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="feature-box text-center p-4">
                    <div class="feature-icon mb-4">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h5 class="mb-3">Industrial Automation</h5>
                    <p class="mb-0">Components for robotics, control systems, and manufacturing.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="feature-box text-center p-4">
                    <div class="feature-icon mb-4">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h5 class="mb-3">Energy</h5>
                    <p class="mb-0">Solutions for power generation, distribution, and renewable energy.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Industry Solutions End -->

<!-- CTA Start -->
<div class="container bg-primary py-5">
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-lg-8">
                <h1 class="display-5 text-white mb-3">Ready to Power Your Next Project?</h1>
                <p class="fs-4 text-white mb-0">Contact our team of experts to discuss your electronic component needs and discover how Encore Global can support your business.</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="contact.php" class="btn btn-light py-3 px-5">Contact Us</a>
            </div>
        </div>
    </div>
</div>
<!-- CTA End -->

<a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>

<?php include '../include/layout/footer.php' ?>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= HTTP_SERVER ?>lib/wow/wow.min.js"></script>
<script src="<?= HTTP_SERVER ?>lib/easing/easing.min.js"></script>
<script src="<?= HTTP_SERVER ?>lib/waypoints/waypoints.min.js"></script>
<script src="<?= HTTP_SERVER ?>lib/counterup/counterup.min.js"></script>
<script src="<?= HTTP_SERVER ?>lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Template Javascript -->
<script src="<?= HTTP_SERVER ?>js/main.js"></script>

</body>

</html>